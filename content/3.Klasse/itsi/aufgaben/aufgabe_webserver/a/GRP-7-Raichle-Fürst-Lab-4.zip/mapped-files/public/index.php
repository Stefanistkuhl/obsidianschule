<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>title</title>
</head>
<body>
        <h1><?php echo 'Hello, World!'; ?></h1>
        <a href="private/private.php">privat</a>
        <button onclick="location.href='private/private.php'">privat</button>
</body>
</html>
