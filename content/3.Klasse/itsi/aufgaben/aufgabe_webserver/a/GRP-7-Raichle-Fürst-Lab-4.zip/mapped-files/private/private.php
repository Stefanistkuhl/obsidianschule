<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privat</title>
</head>
<body>
        <h1>Gruppe 7</h1>
        <h2>Stefan Fürst, Marcel Raichle</h2>
        <img src="https://i.imgur.com/G0ZDQPD.jpeg" alt="ai fucking sucks">
        <h3>Hello <?php echo $_SERVER['PHP_AUTH_USER']; ?></h3>
</body>
</html>
